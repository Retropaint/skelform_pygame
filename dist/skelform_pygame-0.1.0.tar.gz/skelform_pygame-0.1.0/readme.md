# SkelForm Pygame

SkelForm runtime for Pygame. Uses the [generic runtime](https://pypi.org/project/skelform-python/)
